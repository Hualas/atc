<?php

    class TemplateController{
        public function template(){
            include_once "main.php";
        }
    }