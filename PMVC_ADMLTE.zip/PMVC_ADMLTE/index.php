<?php

require_once "controllers/controller-main.php";

$template = new TemplateController();
$template -> template();
