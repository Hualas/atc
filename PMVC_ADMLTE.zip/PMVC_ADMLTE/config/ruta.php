<?php
    const SERVERURL = "http://127.0.0.1/ADMLTE_PLANTILLA/";